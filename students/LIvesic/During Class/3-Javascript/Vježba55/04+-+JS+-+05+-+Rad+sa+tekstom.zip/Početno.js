var text = ' Lorem ipsum dolor sit amet';

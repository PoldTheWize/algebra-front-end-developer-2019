var x = "Lorem ipsum",
    y = 2345,
    z = "2345"
	q = false,
	w;

x += '3' + 1;
var baaa = "b" + "a" + +"a" + "a";


/**
// Inicijalizacija varijabli?
*/
var first_name = "Tony";

var first_name = "John",
lastName = Doe,
price = 0,
0discount = 78,
fullPrice == 0,
break = [], /*
$myObject = {};

console.log(PRICE);
console.log(lastname);

// Kraj mog
programa
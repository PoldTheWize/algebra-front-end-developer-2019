// 1.
var dobro = "1234567890";
var lose = "1123456";
var jedinstveniZnakovi = function(password) {
	// vas kod
};

jedinstveniZnakovi(dobro);
jedinstveniZnakovi(lose);
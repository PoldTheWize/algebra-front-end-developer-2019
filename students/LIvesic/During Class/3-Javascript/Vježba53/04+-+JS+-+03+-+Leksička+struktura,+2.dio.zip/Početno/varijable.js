var firstName,      lastName, price, discount, fullPrice;

firstName =     "John";
    lastName = "Doe"

price = 19.90;
discount = 0.10;

if (x == 1)
x = 2
	
	if (a) {
	var z = 44
		return 0;
	}

fullPrice = price * 100 / discount;